<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PostResource\Pages;
use App\Filament\Resources\PostResource\RelationManagers;
use App\Models\Post;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class PostResource extends Resource
{
    protected static ?string $model = Post::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                    \Filament\Forms\Components\FileUpload::make('image') // Subida de imagen
                        ->label('Image')
                        ->image()
                        ->required(),
    
                    \Filament\Forms\Components\TextInput::make('author') // Campo del autor
                        ->label('Author')
                        ->required()
                        ->maxLength(255),
    
                    \Filament\Forms\Components\TextInput::make('title') // Campo para el título
                        ->label('Title')
                        ->required()
                        ->maxLength(255),
    
                    \Filament\Forms\Components\Textarea::make('content') // Campo para el contenido
                        ->label('Content')
                        ->required(),
    
                    \Filament\Forms\Components\Select::make('category_id') // Campo select para la categoría
                        ->label('Category')
                        ->relationship('category', 'name') // Relación con el modelo Category
                        ->required(),
                ]);
    }

    public static function table(Table $table): Table
    {
        return $table
        ->columns([
            \Filament\Tables\Columns\ImageColumn::make('image') // Columna de imagen
                ->label('Imagen')
                ->rounded(),

            \Filament\Tables\Columns\TextColumn::make('author') // Columna de autor
                ->label('Autor')
                ->sortable()
                ->searchable(),

            \Filament\Tables\Columns\TextColumn::make('title') // Columna del título
                ->label('Título')
                ->sortable()
                ->searchable(),

            \Filament\Tables\Columns\TextColumn::make('category.name') // Columna para mostrar el nombre de la categoría
                ->label('Categoría')
                ->sortable()
                ->searchable(),

        ])
        ->filters([
            // Puedes agregar filtros personalizados aquí
        ])
        ->actions([
            \Filament\Tables\Actions\EditAction::make(), // Acción para editar registros
            \Filament\Tables\Actions\DeleteAction::make(), // Acción para eliminar un registro
        ])
        ->bulkActions([
            \Filament\Tables\Actions\DeleteBulkAction::make(), // Acción para eliminar en masa
        ]);
    }
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPosts::route('/'),
            'create' => Pages\CreatePost::route('/create'),
            'edit' => Pages\EditPost::route('/{record}/edit'),
        ];
    }
}
