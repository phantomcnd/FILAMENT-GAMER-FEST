<img src="{{ asset('img/transparente.png') }}" alt="Logo" class="w-32 h-32">
