<img src="<?php echo e(asset('img/transparente.png')); ?>" alt="Logo" class="w-32 h-32">
<?php /**PATH C:\Users\chris\gfest\resources\views/components/application-logo.blade.php ENDPATH**/ ?>